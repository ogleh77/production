CREATE TRIGGER trigger_add_recycle
    AFTER  DELETE
    ON customer

BEGIN
    INSERT INTO recycle(costumer_id, first_name, last_name, phone, gender, paid_by, paid, discount, shift, exp_date,
                        weight, box_fk, poxing, image, user_added, date_joined)
    VALUES (old.costumer_id, old.first_name, old.last_name, old.phone, old.gender, old.paid_by, old.paid, old.discount,
            old.shift, old.exp_date, old.weight, 0, old.poxing, old.image, old.user_added, old.date_joined);
END;

